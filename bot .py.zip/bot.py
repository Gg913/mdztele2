import requests, telebot, json
from telebot import types
bot = telebot.TeleBot("6285247410:AAE04m8GbV6VZ3U3qNrx00ZmqZ8fZ-NZb94")

'''
by: @DuDrD / @iq_python
translated by: @EUTHEUZIN / @CardersDo7
'''


SS = "dev = @DuDrD\ntranslated: @EUTHEUZIN"
url = 'https://us-central1-chat-for-chatgpt.cloudfunctions.net/basicUserRequestBeta'

def gpt(text) -> str:
 headers = {
     'Host': 'us-central1-chat-for-chatgpt.cloudfunctions.net',
     'Connection': 'keep-alive',
     'If-None-Match': 'W/"1c3-Up2QpuBs2+QUjJl/C9nteIBUa00"',
     'Accept': '*/*',
     'User-Agent': 'com.tappz.aichat/1.2.2 iPhone/15.6.1 hw/iPhone8_2',
     'Content-Type': 'application/json',
     'Accept-Language': 'en-GB,en;q=0.9'
 }
 
 data = {
     'data': {
         'message':text,
     }
 }

 response = requests.post(url, headers=headers, data=json.dumps(data))
 try:
  result = response.json()["result"]["choices"][0]["text"]
  return result
 except:
  return None 
S = "RUN BOT "
@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    msg = gpt(message.text)
    if msg:
        markup = telebot.types.InlineKeyboardMarkup()
        markup.add(telebot.types.InlineKeyboardButton(text='Entrar', url="https://t.me/mdzup"))
        bot.reply_to(message, msg, reply_markup=markup)
    else:
        bot.reply_to(message, "Não entendi sua pergunta:/")
print(S)
print(SS)
bot.polling()