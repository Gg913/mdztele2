"""Handlers of commands from user"""

from aiogram import Dispatcher
from aiogram.types import InputFile, Message

from tgbot.config import BOT_LOGO
from tgbot.middlewares.localization import i18n

_ = i18n.gettext  # Alias for gettext method


async def if_user_sent_command_start(message: Message) -> None:
    """Handles command /start from the user"""
    lang_code: str = message.from_user.language_code
    answer_text: str = (
        _("Digite o nome da música ou mande-me um link para o vídeo de", locale=lang_code)
        + ' <a href="https://www.youtube.com">YouTube</a>. 😉'
    )
    await message.answer_photo(photo=InputFile(BOT_LOGO), caption=answer_text)


async def if_user_sent_command_about(message: Message) -> None:
    """Handles command /about from the user"""
    lang_code: str = message.from_user.language_code
    answer_text: str = (
        _("Eu posso baixar músicas de", locale=lang_code)
        + ' <a href="https://www.youtube.com">YouTube</a>!\n\n'
        + _("Digite o nome da música ou mande-me um link para o vídeo", locale=lang_code)
    )
    await message.answer_photo(photo=InputFile(BOT_LOGO), caption=answer_text)


def register_commands(dp: Dispatcher) -> None:
    """Registers command handlers"""
    dp.register_message_handler(if_user_sent_command_start, commands="start", state=None)
    dp.register_message_handler(if_user_sent_command_about, commands="about", state=None)
